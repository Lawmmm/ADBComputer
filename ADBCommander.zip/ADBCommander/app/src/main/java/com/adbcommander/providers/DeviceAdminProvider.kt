package com.adbcommander.providers

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.adbcommander.receiver.DeviceAdminReceiver

class DeviceAdminProvider : ActivationProvider {
    override val name = "设备管理员"
    override val priority = 4
    
    private var devicePolicyManager: DevicePolicyManager? = null
    private var componentName: ComponentName? = null
    
    fun init(context: Context) {
        if (devicePolicyManager == null) {
            devicePolicyManager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            componentName = ComponentName(context, DeviceAdminReceiver::class.java)
        }
    }
    
    override fun isAvailable(): Boolean = true
    
    override fun isActivated(): Boolean {
        return devicePolicyManager?.isAdminActive(componentName!!) == true
    }
    
    override fun activate(context: Context, callback: (Boolean) -> Unit) {
        init(context)
        
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, 
                "需要设备管理员权限来冻结应用和清除数据")
        }
        context.startActivity(intent)
        callback(false) // 需要用户手动确认
    }
    
    override fun executeCommand(command: String): String {
        init(com.adbcommander.App.instance)
        
        if (!isActivated()) {
            return "❌ 设备管理员未激活"
        }
        
        return try {
            when {
                command.startsWith("pm disable") -> {
                    val packageName = command.split(" ")[2]
                    devicePolicyManager?.setApplicationHidden(componentName!!, packageName, true)
                    "✅ 已禁用: $packageName"
                }
                command.startsWith("pm enable") -> {
                    val packageName = command.split(" ")[2]
                    devicePolicyManager?.setApplicationHidden(componentName!!, packageName, false)
                    "✅ 已启用: $packageName"
                }
                command.startsWith("pm clear") -> {
                    val packageName = command.split(" ")[2]
                    devicePolicyManager?.wipeData(componentName!!, 0, packageName)
                    "✅ 已清除: $packageName"
                }
                command == "lock" -> {
                    devicePolicyManager?.lockNow()
                    "✅ 屏幕已锁定"
                }
                else -> "⚠️ 不支持的命令: $command"
            }
        } catch (e: Exception) {
            "❌ 执行失败: ${e.message}"
        }
    }
}
