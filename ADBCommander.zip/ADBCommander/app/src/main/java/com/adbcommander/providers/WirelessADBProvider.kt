package com.adbcommander.providers

import android.content.Context
import android.os.Build
import android.provider.Settings

class WirelessADBProvider : ActivationProvider {
    override val name = "无线ADB"
    override val priority = 2
    
    override fun isAvailable(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R // Android 11+
    }
    
    override fun isActivated(): Boolean {
        return try {
            val port = Settings.Global.getInt(
                com.adbcommander.App.instance.contentResolver,
                "adb_wifi_port",
                0
            )
            port > 0
        } catch (e: Exception) {
            false
        }
    }
    
    override fun activate(context: Context, callback: (Boolean) -> Unit) {
        try {
            // 引导到开发者选项
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            context.startActivity(intent)
            Toast.makeText(context, "请手动开启无线调试", Toast.LENGTH_LONG).show()
            callback(false)
        } catch (e: Exception) {
            callback(false)
        }
    }
    
    override fun executeCommand(command: String): String {
        if (!isActivated()) {
            return "❌ 无线ADB未开启"
        }
        
        return try {
            val process = Runtime.getRuntime().exec(
                arrayOf("sh", "-c", "adb -s localhost:\$(
                    settings get global adb_wifi_port
                ) shell $command")
            )
            process.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            "❌ 无线ADB执行失败: ${e.message}"
        }
    }
}
