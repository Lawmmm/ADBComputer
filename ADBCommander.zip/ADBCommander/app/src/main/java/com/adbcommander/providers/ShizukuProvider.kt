package com.adbcommander.providers

import android.content.Context
import android.content.pm.PackageManager
import dev.rikka.shizuku.Shizuku
import java.io.BufferedReader

class ShizukuProvider : ActivationProvider {
    override val name = "Shizuku"
    override val priority = 3
    
    override fun isAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
    }
    
    override fun isActivated(): Boolean {
        return try {
            Shizuku.pingBinder() && 
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }
    
    override fun activate(context: Context, callback: (Boolean) -> Unit) {
        if (!isAvailable()) {
            // 未安装Shizuku
            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                context.startActivity(intent)
            } else {
                // 打开浏览器下载
                val downloadIntent = android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://shizuku.rikka.app/")
                )
                context.startActivity(downloadIntent)
            }
            callback(false)
            return
        }
        
        if (!isActivated()) {
            // 请求授权
            Shizuku.requestPermission(0)
            callback(true)
        } else {
            callback(true)
        }
    }
    
    override fun executeCommand(command: String): String {
        if (!isActivated()) {
            return "❌ Shizuku未授权"
        }
        
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val output = process.inputStream.bufferedReader().use(BufferedReader::readText)
            val error = process.errorStream.bufferedReader().use(BufferedReader::readText)
            
            process.waitFor()
            
            if (error.isNotEmpty()) "Error: $error" else output
        } catch (e: Exception) {
            "❌ 执行失败: ${e.message}"
        }
    }
}
