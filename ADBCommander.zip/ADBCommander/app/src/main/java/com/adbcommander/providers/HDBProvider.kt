package com.adbcommander.providers

import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.os.Build

class HDBProvider : ActivationProvider {
    override val name = "华为HDB"
    override val priority = 1
    
    override fun isAvailable(): Boolean {
        val brand = Build.BRAND ?: ""
        val manufacturer = Build.MANUFACTURER ?: ""
        return brand.equals("HUAWEI", ignoreCase = true) || 
               manufacturer.equals("HUAWEI", ignoreCase = true) ||
               brand.equals("HONOR", ignoreCase = true)
    }
    
    override fun isActivated(): Boolean {
        return try {
            val result = executeCommand("echo test")
            result.contains("test")
        } catch (e: Exception) {
            false
        }
    }
    
    override fun activate(context: Context, callback: (Boolean) -> Unit) {
        try {
            // 直接打开HDB授权页面
            val intent = Intent().apply {
                component = ComponentName(
                    "com.android.settings",
                    "com.android.settings.HdbAuthorizationActivity"
                )
                putExtra("packageName", context.packageName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            callback(true)
        } catch (e: Exception) {
            // 备用方案：打开安全设置
            val intent = Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS)
            context.startActivity(intent)
            callback(false)
        }
    }
    
    override fun executeCommand(command: String): String {
        return try {
            // 尝试连接本地HDB服务
            val process = Runtime.getRuntime().exec(
                arrayOf("sh", "-c", "adb -s localhost:5555 shell $command")
            )
            
            val output = process.inputStream.bufferedReader().readText()
            val error = process.errorStream.bufferedReader().readText()
            
            process.waitFor()
            
            if (output.isNotEmpty()) output else error
        } catch (e: Exception) {
            "❌ HDB执行失败: ${e.message}"
        }
    }
}
