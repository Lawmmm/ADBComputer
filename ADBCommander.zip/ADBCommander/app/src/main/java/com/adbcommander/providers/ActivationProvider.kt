package com.adbcommander.providers

import android.content.Context

interface ActivationProvider {
    val name: String
    val priority: Int
    fun isAvailable(): Boolean
    fun isActivated(): Boolean
    fun activate(context: Context, callback: (Boolean) -> Unit)
    fun executeCommand(command: String): String
}
