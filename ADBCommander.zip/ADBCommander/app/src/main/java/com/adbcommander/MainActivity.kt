package com.adbcommander

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.adbcommander.core.ActivationManager
import com.adbcommander.core.ADBExecutor
import com.adbcommander.databinding.ActivityMainBinding
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var activationManager: ActivationManager
    private var currentProvider: com.adbcommander.providers.ActivationProvider? = null
    
    private val mainScope = MainScope()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        
        activationManager = ActivationManager(this)
        
        initViews()
        checkActivationStatus()
    }
    
    private fun initViews() {
        binding.btnActivate.setOnClickListener {
            showActivationDialog()
        }
        
        binding.btnExecute.setOnClickListener {
            executeCommand()
        }
        
        binding.fabPresets.setOnClickListener {
            showPresetCommands()
        }
    }
    
    private fun checkActivationStatus() {
        currentProvider = activationManager.getActivatedProvider()
        
        if (currentProvider != null) {
            binding.tvStatus.text = "✅ 已激活: ${currentProvider?.name}"
            binding.btnActivate.text = "切换激活方式"
            binding.btnExecute.isEnabled = true
        } else {
            binding.tvStatus.text = "❌ 未激活"
            binding.btnActivate.text = "选择激活方式"
            binding.btnExecute.isEnabled = false
            
            // 自动推荐最佳方式
            val best = activationManager.getBestAvailableProvider()
            if (best != null) {
                binding.tvStatus.text = "${binding.tvStatus.text}\n推荐: ${best.name}"
            }
        }
    }
    
    private fun showActivationDialog() {
        val providers = activationManager.getAvailableProviders()
        
        if (providers.isEmpty()) {
            Toast.makeText(this, "无可用的激活方式", Toast.LENGTH_SHORT).show()
            return
        }
        
        val items = providers.map { "${it.name} (${if (it.isActivated()) "已激活" else "未激活"})" }.toTypedArray()
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("选择激活方式")
            .setItems(items) { _, which ->
                val provider = providers[which]
                provider.activate(this) { success ->
                    if (success || provider.isActivated()) {
                        checkActivationStatus()
                    }
                }
            }
            .show()
    }
    
    private fun executeCommand() {
        val command = binding.etCommand.text.toString().trim()
        if (command.isEmpty()) {
            Toast.makeText(this, "请输入命令", Toast.LENGTH_SHORT).show()
            return
        }
        
        val provider = currentProvider
        if (provider == null) {
            Toast.makeText(this, "请先激活", Toast.LENGTH_SHORT).show()
            return
        }
        
        binding.btnExecute.isEnabled = false
        binding.tvOutput.text = "执行中...\n\n$ ${command}\n\n"
        
        mainScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    provider.executeCommand(command)
                } catch (e: Exception) {
                    "❌ 错误: ${e.message}"
                }
            }
            
            binding.tvOutput.append(result)
            binding.btnExecute.isEnabled = true
            
            // 自动滚动到底部
            binding.tvOutput.post {
                binding.tvOutput.parent.parent.requestLayout()
            }
        }
    }
    
    private fun showPresetCommands() {
        val presets = arrayOf(
            "pm list packages | grep -i qq",
            "pm list packages -s",
            "dumpsys activity top | grep ACTIVITY",
            "settings get secure android_id",
            "settings put global adb_wifi_enabled 1"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("预设命令")
            .setItems(presets) { _, which ->
                binding.etCommand.setText(presets[which])
            }
            .show()
    }
    
    fun getCurrentProvider() = currentProvider
    
    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}
